import joblib
import pandas as pd
from datetime import datetime

# === Load the trained model ===
model_path = r"C:\Users\karam\OneDrive\Desktop\CodSoft\Fraud\fraud_model.pkl"
model = joblib.load(model_path)

# === List of input features (used during training) ===
feature_names = [
    'cc_num', 'merchant', 'category', 'amt', 'first', 'last', 'gender',
    'street', 'city', 'state', 'zip', 'lat', 'long', 'city_pop', 'job',
    'unix_time', 'merch_lat', 'merch_long', 'age', 'hour'
]

# === Collect input from the user ===
print("🔍 Enter transaction details:")
data = {}
data['cc_num'] = input("Credit Card Number (digits only): ")
data['merchant'] = input("Merchant Name: ")
data['category'] = input("Category (e.g., gas_transport, shopping_pos): ")
data['amt'] = float(input("Transaction Amount: "))
data['first'] = input("First Name: ")
data['last'] = input("Last Name: ")
data['gender'] = input("Gender (M/F): ")
data['street'] = input("Street: ")
data['city'] = input("City: ")
data['state'] = input("State (e.g., NY, CA): ")
data['zip'] = int(input("Zip Code: "))
data['lat'] = float(input("Latitude: "))
data['long'] = float(input("Longitude: "))
data['city_pop'] = int(input("City Population: "))
data['job'] = input("Job Title: ")
data['unix_time'] = int(input("Unix Time (e.g., 1325376018): "))
data['merch_lat'] = float(input("Merchant Latitude: "))
data['merch_long'] = float(input("Merchant Longitude: "))
dob = input("Date of Birth (YYYY-MM-DD): ")
trans_time = input("Transaction Time (YYYY-MM-DD HH:MM:SS): ")

# Calculate age and transaction hour
dob_date = pd.to_datetime(dob, errors='coerce')
trans_dt = pd.to_datetime(trans_time, errors='coerce')

data['age'] = 2025 - dob_date.year
data['hour'] = trans_dt.hour

# Create DataFrame
df = pd.DataFrame([data])

# === Encode categorical features (using LabelEncoder logic) ===
# NOTE: In production, you should save and reuse the encoders used during training.
# Here we re-fit on the same single value (not ideal but works for demo).

for col in df.select_dtypes(include='object').columns:
    df[col] = pd.factorize(df[col])[0]

# Ensure correct order of columns
df = df[feature_names]

# === Predict ===
prediction = model.predict(df)[0]

# === Output result ===
if prediction == 1:
    print("🚨 This transaction is predicted to be: FRAUDULENT")
else:
    print("✅ This transaction is predicted to be: LEGITIMATE")
